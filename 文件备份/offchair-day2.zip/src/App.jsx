import './App.css'

const sampleServices = [
  {
    id: 1,
    title: "学生美甲体验",
    description: "美甲爱好者，非职业，30元尝试体验～",
    price: 30,
    location: "上海 · 徐汇",
    image: "https://images.unsplash.com/photo-1586942385475-a9a3b4c3c5ff"
  },
  {
    id: 2,
    title: "业余摄影接单",
    description: "风景、人像拍摄，周末拍摄，价格便宜",
    price: 50,
    location: "北京 · 海淀",
    image: "https://images.unsplash.com/photo-1518779578993-ec3579fee39f"
  }
];

function App() {
  return (
    <div>
      <h1>Offchair 兴趣服务平台</h1>
      <div style={{ display: "flex", flexWrap: "wrap", gap: "20px", marginTop: "20px" }}>
        {sampleServices.map(service => (
          <div key={service.id} style={{
            border: "1px solid #ccc",
            borderRadius: "8px",
            padding: "16px",
            width: "250px",
            boxShadow: "2px 2px 10px rgba(0,0,0,0.1)"
          }}>
            <img src={service.image} alt={service.title} style={{
              width: "100%",
              height: "150px",
              objectFit: "cover",
              borderRadius: "4px"
            }} />
            <h3>{service.title}</h3>
            <p>{service.description}</p>
            <p><strong>价格：</strong> ¥{service.price}</p>
            <p><strong>地点：</strong> {service.location}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
